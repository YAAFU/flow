"use client";
/* eslint-disable react-hooks/set-state-in-effect, react-hooks/exhaustive-deps */
import { useEffect, useRef, useState } from "react";
import { AlertTriangle, ArrowRight, MapPin, RotateCcw } from "lucide-react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import type { ScheduleItem } from "@/lib/types";
import { resolvePlace, BKK_CENTER } from "@/lib/places";

const STYLE = "https://basemaps.cartocdn.com/gl/positron-gl-style/style.json"; // no-key monochrome

type Stop = { label: string; lat?: number; lng?: number; travelFromPrevMin: number; start: string; end: string };
type Leg = { durationMin: number; distanceKm: number };
type Point = { lat: number; lng: number };
type RouteResponse = { geometry?: unknown; legs?: unknown; fallback?: unknown };

// names already geocoded this session (null = Nominatim couldn't find it either)
const geoCache = new Map<string, Point | null>();

function isPoint(value: unknown): value is Point {
  if (typeof value !== "object" || value === null) return false;
  const point = value as Partial<Point>;
  return typeof point.lat === "number" && Number.isFinite(point.lat) && point.lat >= -90 && point.lat <= 90
    && typeof point.lng === "number" && Number.isFinite(point.lng) && point.lng >= -180 && point.lng <= 180;
}

function isGeometry(value: unknown): value is [number, number][] {
  return Array.isArray(value) && value.length >= 2 && value.every((coordinate) => (
    Array.isArray(coordinate) && coordinate.length >= 2 && isPoint({ lat: coordinate[1], lng: coordinate[0] })
  ));
}

function isLegs(value: unknown): value is Leg[] {
  return Array.isArray(value) && value.every((leg) => {
    if (typeof leg !== "object" || leg === null) return false;
    const item = leg as Partial<Leg>;
    return typeof item.durationMin === "number" && Number.isFinite(item.durationMin) && item.durationMin >= 0
      && typeof item.distanceKm === "number" && Number.isFinite(item.distanceKm) && item.distanceKm >= 0;
  });
}

function fitLocated(map: maplibregl.Map, points: Array<{ lat: number; lng: number }>, duration = 0) {
  if (points.length === 1) {
    map.flyTo({ center: [points[0].lng, points[0].lat], zoom: 14, duration });
    return;
  }
  const bounds = points.reduce(
    (current, point) => current.extend([point.lng, point.lat]),
    new maplibregl.LngLatBounds([points[0].lng, points[0].lat], [points[0].lng, points[0].lat]),
  );
  map.fitBounds(bounds, { padding: 45, duration });
}

export function FlowMap({ items, coords, focus: focusProp, onFocus }: { items: ScheduleItem[]; coords?: Record<string, { lat: number; lng: number }>; focus?: number; onFocus?: React.Dispatch<React.SetStateAction<number>> }) {
  const ref = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const [failed, setFailed] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const [focusState, setFocusState] = useState(-1); // -1 = overview, else stop index
  const focus = focusProp ?? focusState;
  const setFocus = onFocus ?? setFocusState;
  const [legs, setLegs] = useState<Leg[]>([]);
  const [routeFallback, setRouteFallback] = useState(false);
  const [, setGeoVersion] = useState(0); // bump to re-render when geoCache gains entries

  // keep EVERY schedule item so stop numbers always match the plan order -
  // unresolved places just have no pin instead of silently shifting the numbering
  const stops: Stop[] = items.map((it) => {
    const candidates = [coords?.[it.taskId], resolvePlace(it.placeLabel), geoCache.get(it.placeLabel)];
    const p = candidates.find(isPoint);
    return { label: it.placeLabel, lat: p?.lat, lng: p?.lng, travelFromPrevMin: it.travelFromPrevMin, start: it.start, end: it.end };
  });
  const unknownLabels = [...new Set(stops
    .filter((stop) => stop.lat == null && stop.label.trim().length >= 2 && !geoCache.has(stop.label))
    .map((stop) => stop.label))];

  // names neither the task coords nor the built-in list know → ask Nominatim once
  useEffect(() => {
    if (unknownLabels.length === 0) return;
    let cancelled = false;
    const controller = new AbortController();
    (async () => {
      for (const label of unknownLabels) {
        try {
          const r = await fetch(`/api/geocode?q=${encodeURIComponent(label)}`, { signal: controller.signal });
          if (!r.ok) throw new Error("geocode failed");
          const hits = await r.json() as unknown;
          const point = Array.isArray(hits) ? hits.find(isPoint) : undefined;
          geoCache.set(label, point ?? null);
        } catch {
          if (!controller.signal.aborted) geoCache.set(label, null);
        }
      }
      if (!cancelled) setGeoVersion((v) => v + 1);
    })();
    return () => { cancelled = true; controller.abort(); };
  }, [JSON.stringify(unknownLabels)]);
  const located = stops
    .map((s, i) => (isPoint(s) ? { i, lat: s.lat, lng: s.lng } : null))
    .filter((x): x is { i: number; lat: number; lng: number } => x !== null);
  const locatedSignature = JSON.stringify(located.map((point) => [point.i, point.lat, point.lng]));
  // routeIdx[stopIndex] → position in the OSRM coord list (for leg lookup)
  const routeIdx: Record<number, number> = {};
  located.forEach((l, idx) => { routeIdx[l.i] = idx; });

  useEffect(() => {
    if (!ref.current || failed || located.length === 0) return;
    let map: maplibregl.Map | null = null;
    let disposed = false;
    const routeController = new AbortController();
    let loadTimeout: ReturnType<typeof setTimeout> | undefined;
    let resizeObserver: ResizeObserver | undefined;
    setMapReady(false);
    setLegs([]);
    setRouteFallback(false);
    try {
      map = new maplibregl.Map({ container: ref.current, style: STYLE, center: [BKK_CENTER.lng, BKK_CENTER.lat], zoom: 11, attributionControl: false });
      mapRef.current = map;
      const activeMap = map;
      loadTimeout = setTimeout(() => {
        if (!disposed && !activeMap.isStyleLoaded()) setFailed(true);
      }, 12_000);
      if (typeof ResizeObserver !== "undefined") {
        resizeObserver = new ResizeObserver(() => activeMap.resize());
        resizeObserver.observe(ref.current);
      }
      map.once("load", () => void (async () => {
        if (loadTimeout) clearTimeout(loadTimeout);
        if (disposed) return;
        activeMap.resize();
        // numbered pins - stops at the same coordinates share ONE pin listing
        // every stop number (otherwise pins stack and only the top number shows)
        const groups = new Map<string, { lat: number; lng: number; nums: number[] }>();
        located.forEach((l) => {
          const key = `${l.lat.toFixed(4)},${l.lng.toFixed(4)}`;
          const g = groups.get(key) ?? { lat: l.lat, lng: l.lng, nums: [] };
          g.nums.push(l.i + 1);
          groups.set(key, g);
        });
        groups.forEach((g) => {
          const el = document.createElement("div");
          el.textContent = g.nums.join("·");
          el.setAttribute("aria-label", `จุดที่ ${g.nums.join(", ")}`);
          el.style.cssText = "min-width:30px;height:30px;padding:0 8px;border-radius:15px;background:#111;color:#d6ff3f;display:flex;align-items:center;justify-content:center;font-weight:700;font-family:'Space Grotesk';box-shadow:0 1px 6px rgba(0,0,0,.3)";
          new maplibregl.Marker({ element: el }).setLngLat([g.lng, g.lat]).addTo(activeMap);
        });

        fitLocated(activeMap, located);
        setMapReady(true);
        if (located.length < 2) return;

        // real road route via OSRM (fallback to straight line inside the API)
        let geometry: [number, number][] = located.map((l) => [l.lng, l.lat]);
        let fallbackRoute = false;
        try {
          const r = await fetch("/api/route", {
            method: "POST", headers: { "content-type": "application/json" },
            body: JSON.stringify({ mode: "route", coords: located.map((l) => ({ lat: l.lat, lng: l.lng })) }),
            signal: routeController.signal,
          });
          if (!r.ok) throw new Error("route failed");
          const data = await r.json() as RouteResponse;
          if (disposed || !isGeometry(data.geometry) || !isLegs(data.legs) || data.legs.length !== located.length - 1) {
            throw new Error("invalid route response");
          }
          geometry = data.geometry;
          setLegs(data.legs);
          fallbackRoute = data.fallback === true;
          setRouteFallback(fallbackRoute);
        } catch {
          if (!routeController.signal.aborted) {
            fallbackRoute = true;
            setRouteFallback(true);
          }
        }

        if (disposed) return;

        if (!activeMap.getSource("route")) {
          activeMap.addSource("route", { type: "geojson", data: { type: "Feature", geometry: { type: "LineString", coordinates: geometry }, properties: {} } });
          activeMap.addLayer({ id: "route", type: "line", source: "route", paint: { "line-color": "#111", "line-width": 4, "line-opacity": 0.85, "line-dasharray": fallbackRoute ? [2, 2] : [1, 0] } });
        }
        fitLocated(activeMap, geometry.map(([lng, lat]) => ({ lat, lng })));
      })());
    } catch { setFailed(true); }
    return () => {
      disposed = true;
      routeController.abort();
      if (loadTimeout) clearTimeout(loadTimeout);
      resizeObserver?.disconnect();
      try { map?.remove(); } catch {}
      mapRef.current = null;
    };
  }, [failed, locatedSignature]);

  // step-through: fly to the focused stop (if it has coordinates)
  useEffect(() => {
    const map = mapRef.current;
    const s = focus >= 0 ? stops[focus] : null;
    if (!map || !s || s.lat == null || s.lng == null) return;
    map.flyTo({ center: [s.lng, s.lat], zoom: 15, duration: 700 });
  }, [focus, locatedSignature]);

  function next() {
    setFocus((f) => (f + 1 >= stops.length ? -1 : f + 1)); // loop: ...last → overview → first
  }
  function overview() {
    setFocus(-1);
    const map = mapRef.current;
    if (map && located.length) fitLocated(map, located, 700);
  }

  if (items.length === 0) {
    return <MapState title="ยังไม่มีงานที่จัดเวลา" detail="เพิ่มเวลาและสถานที่ให้กับงานก่อน แล้ว Flow จะแสดงลำดับการเดินทางที่นี่" />;
  }
  if (located.length === 0 && unknownLabels.length > 0) {
    return <MapState title="กำลังค้นหาพิกัดสถานที่" detail="Flow กำลังตรวจสอบสถานที่ของงานเพื่อเตรียมแผนที่" busy />;
  }
  if (located.length === 0) {
    return <MapState title="ยังไม่มีพิกัดสำหรับแสดงบนแผนที่" detail="เพิ่มหรือเลือกสถานที่ให้กับงานก่อนจึงจะจัดเส้นทางได้" actionLabel="ลองค้นหาพิกัดอีกครั้ง" onAction={() => {
      stops.forEach((stop) => { if (geoCache.get(stop.label) === null) geoCache.delete(stop.label); });
      setGeoVersion((version) => version + 1);
    }} />;
  }
  if (failed) {
    return <MapState title="เปิดแผนที่ไม่ได้ในขณะนี้" detail="ข้อมูลสถานที่ยังอยู่ครบ แต่บริการแผนที่อาจไม่พร้อมใช้งาน" actionLabel="ลองเปิดแผนที่อีกครั้ง" onAction={() => setFailed(false)} warning />;
  }
  const cur = focus >= 0 ? stops[focus] : null;
  // leg distance only when this stop and the previous one are consecutive on the road route
  const leg = cur && focus > 0 && routeIdx[focus] != null && routeIdx[focus - 1] === routeIdx[focus] - 1
    ? legs[routeIdx[focus] - 1] : null;

  return (
    <div className="flex flex-col gap-2">
      <div className="relative">
        <div ref={ref} role="region" aria-label="แผนที่ลำดับสถานที่ของวัน" className="h-[300px] w-full overflow-hidden rounded-2xl border-[1.5px] border-[var(--flow-ink)]" />
        {!mapReady && <div role="status" className="absolute inset-0 grid place-items-center rounded-2xl bg-[var(--flow-surface)] text-sm text-[var(--flow-muted)]">กำลังเปิดแผนที่…</div>}
      </div>
      {routeFallback && <p role="status" className="flex items-start gap-2 rounded-xl border border-[var(--flow-warning)] p-3 text-xs text-[var(--flow-warning)]"><AlertTriangle size={15} className="mt-0.5 shrink-0" aria-hidden />บริการเส้นทางไม่พร้อม เส้นประและเวลาเดินทางเป็นค่าประมาณ</p>}

      {/* controls + current-stop status: sticky so the active step stays visible while the list scrolls */}
      <div className="sticky top-0 z-10 -mx-1 flex flex-col gap-2 bg-[var(--flow-paper)] px-1 pb-1 pt-1">
      {/* step-through controls */}
      <div className="flex items-center gap-2">
        <button type="button" onClick={overview} className={`flow-press min-h-11 rounded-full border-[1.5px] border-[var(--flow-ink)] px-4 text-xs font-semibold ${focus < 0 ? "bg-[var(--flow-ink)] text-[var(--flow-lime)]" : ""}`}>ภาพรวม</button>
        <button type="button" onClick={next} className="flow-press flex min-h-11 flex-1 items-center justify-center gap-1.5 rounded-full bg-[var(--flow-ink)] px-3 text-center text-xs font-semibold text-[var(--flow-paper)]">
          {focus < 0 ? "เริ่มดูทีละจุด" : focus + 1 >= stops.length ? "กลับภาพรวม" : "จุดถัดไป"}
          {focus + 1 >= stops.length ? <RotateCcw size={13} className="text-[var(--flow-lime)]" /> : <ArrowRight size={14} className="text-[var(--flow-lime)]" />}
        </button>
      </div>

      {/* current stop detail */}
      {cur ? (
        <div className="rounded-xl border-[1.5px] border-[var(--flow-ink)] bg-[var(--flow-surface)] p-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-semibold">จุดที่ <span className="font-grotesk">{focus + 1}</span> · {cur.label}</span>
            <span className="font-grotesk text-xs text-[var(--flow-muted)]">{cur.start}–{cur.end}</span>
          </div>
          {focus > 0 && (
            <div className="mt-1 text-xs text-[var(--flow-muted)]">
              เดินทางจากจุดก่อนหน้า ~<span className="font-grotesk">{leg?.durationMin ?? cur.travelFromPrevMin}</span> นาที
              {leg?.distanceKm ? <> · <span className="font-grotesk">{leg.distanceKm}</span> กม.</> : null}
            </div>
          )}
          {cur.lat == null && (
            <div className="mt-1 text-xs text-amber-600">ค้นพิกัดของ “{cur.label}” ไม่เจอ - แตะแก้งานแล้วเลือกสถานที่จากช่องค้นหาเพื่อปักหมุด</div>
          )}
        </div>
      ) : (
        <div className="text-xs text-[var(--flow-muted)]">
          ทั้งหมด <span className="font-grotesk">{stops.length}</span> จุดตามลำดับแผน · กด “เริ่มดูทีละจุด” เพื่อไล่ดูเส้นทาง
          {located.length < stops.length && <> · <span className="text-amber-600"><span className="font-grotesk">{stops.length - located.length}</span> จุดยังไม่มีพิกัดบนแผนที่</span></>}
        </div>
      )}
      </div>
    </div>
  );
}

function MapState({ title, detail, busy = false, warning = false, actionLabel, onAction }: {
  title: string;
  detail: string;
  busy?: boolean;
  warning?: boolean;
  actionLabel?: string;
  onAction?: () => void;
}) {
  return (
    <div role={warning ? "alert" : "status"} aria-live="polite" aria-busy={busy || undefined} className="flow-surface flex min-h-[220px] flex-col items-center justify-center rounded-2xl border-[1.5px] border-[var(--flow-line)] p-6 text-center">
      <span className={`grid h-12 w-12 place-items-center rounded-2xl ${warning ? "border border-[var(--flow-warning)] text-[var(--flow-warning)]" : "bg-[var(--flow-lime)] text-[#111111]"}`}>
        {warning ? <AlertTriangle size={21} aria-hidden /> : <MapPin size={21} aria-hidden />}
      </span>
      <h3 className="mt-3 font-bold">{title}</h3>
      <p className="mt-1 max-w-[30ch] text-sm text-[var(--flow-muted)]">{detail}</p>
      {actionLabel && onAction && <button type="button" className="flow-press mt-4 min-h-11 rounded-xl border-[1.5px] border-[var(--flow-ink)] px-4 text-sm font-semibold" onClick={onAction}>{actionLabel}</button>}
    </div>
  );
}
