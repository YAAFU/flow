"use client";
/* eslint-disable react-hooks/set-state-in-effect */

import { useEffect, useRef, useState } from "react";
import { MapPin, Plus, Search, X } from "lucide-react";
import { LocationPicker } from "@/components/LocationPicker";
import type { Category, Priority, Task } from "@/lib/types";
import { createTask } from "@/lib/task-factory";

export interface RepeatDraft { frequency: "none" | "daily" | "weekly" | "monthly" | "yearly"; }

type PlaceDraft = { name: string; lat?: number; lng?: number };
type PlaceHit = { name: string; lat: number; lng: number };

export function AddTaskTrigger({ onClick, variant = "primary" }: { onClick: () => void; variant?: "primary" | "empty" }) {
  return (
    <button
      type="button"
      aria-label={variant === "empty" ? "เพิ่มงานแรกในวันที่เลือก" : "เพิ่มงานในวันที่เลือก"}
      onClick={onClick}
      className={variant === "empty"
        ? "flow-press inline-flex min-h-12 items-center justify-center gap-2 rounded-xl border-[1.5px] border-[var(--flow-line)] bg-[var(--flow-paper)] px-4 text-sm font-semibold"
        : "flow-press flow-inverse flex min-h-14 w-full items-center justify-center gap-2 rounded-2xl border-[1.5px] border-[#111111] px-4 font-semibold shadow-[var(--flow-shadow)]"}
    >
      <span className="grid h-8 w-8 place-items-center rounded-lg bg-[var(--flow-lime)] text-[#111111]"><Plus size={18} aria-hidden /></span>
      {variant === "empty" ? "เพิ่มงานแรก" : "เพิ่มงาน"}
    </button>
  );
}

export function TaskComposer({ categories, date, order, onAdd, open: controlledOpen, onOpenChange, hideTrigger = false }: {
  categories: Category[];
  date: string;
  order: number;
  onAdd: (task: Task, repeat: RepeatDraft) => void;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  hideTrigger?: boolean;
}) {
  const [internalOpen, setInternalOpen] = useState(false);
  const [place, setPlace] = useState<PlaceDraft>({ name: "" });
  const [placeQuery, setPlaceQuery] = useState("");
  const [placeHits, setPlaceHits] = useState<PlaceHit[]>([]);
  const [searchingPlace, setSearchingPlace] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const open = controlledOpen ?? internalOpen;
  const setOpen = (next: boolean) => {
    if (controlledOpen === undefined) setInternalOpen(next);
    onOpenChange?.(next);
  };

  useEffect(() => {
    if (searchTimer.current) clearTimeout(searchTimer.current);
    const query = placeQuery.trim();
    if (query.length < 2) { setPlaceHits([]); setSearchingPlace(false); return; }
    const controller = new AbortController();
    setSearchingPlace(true);
    searchTimer.current = setTimeout(async () => {
      try {
        const response = await fetch(`/api/geocode?q=${encodeURIComponent(query)}`, { signal: controller.signal });
        if (!response.ok) throw new Error("geocode");
        const hits = await response.json() as PlaceHit[];
        setPlaceHits(hits.filter((hit) => Number.isFinite(hit.lat) && Number.isFinite(hit.lng)).slice(0, 6));
      } catch (error) {
        if (!(error instanceof DOMException && error.name === "AbortError")) setPlaceHits([]);
      } finally {
        if (!controller.signal.aborted) setSearchingPlace(false);
      }
    }, 350);
    return () => { controller.abort(); if (searchTimer.current) clearTimeout(searchTimer.current); };
  }, [placeQuery]);

  if (!open) return hideTrigger ? null : <AddTaskTrigger onClick={() => setOpen(true)} />;

  return (
    <form className="flow-form flow-sheet rounded-[22px] border-[1.5px] border-[var(--flow-line)] bg-[var(--flow-paper)] p-4 shadow-[var(--flow-shadow)]" onSubmit={(event) => {
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      const allDay = data.get("allDay") === "on";
      const start=String(data.get("start")||""); const end=String(data.get("end")||"");
      const [startHour,startMinute]=start.split(":").map(Number); const [endHour,endMinute]=end.split(":").map(Number);
      const normalizedDuration=start&&end?Math.max(15,(endHour*60+endMinute)-(startHour*60+startMinute)):Number(data.get("duration")||60);
      const task = createTask({
        title: String(data.get("title") ?? "").trim(),
        place: place.name.trim(),
        lat: place.lat,
        lng: place.lng,
        fixedTime: allDay ? undefined : start || undefined,
        durationMin: normalizedDuration,
        allDay,
        lockTime: data.get("lockTime") === "on",
        deadlineDate: String(data.get("deadlineDate") || "") || undefined,
        deadlineTime: String(data.get("deadlineTime") || "") || undefined,
        priority: String(data.get("priority") || "normal") as Priority,
        categoryId: String(data.get("category") || "") || undefined,
        reminderOffsets: data.getAll("reminder").map(String).filter(Boolean).map(Number),
        note: String(data.get("note") ?? ""),
      }, order);
      onAdd(task, { frequency: String(data.get("repeat") || "none") as RepeatDraft["frequency"] });
      event.currentTarget.reset();
      setPlace({ name: "" });
      setPlaceQuery("");
      setPlaceHits([]);
      setPickerOpen(false);
      setOpen(false);
    }}>
      <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold">เพิ่มงานในวัน</h2><button type="button" aria-label="ปิด" className="grid h-11 w-11 place-items-center rounded-xl border border-[var(--flow-ink)]" onClick={() => { setPickerOpen(false); setOpen(false); }}><X size={18} /></button></div>
      <label className="block text-sm font-semibold" htmlFor="task-title">ชื่องาน</label>
      <input id="task-title" name="title" required autoFocus className="mt-1 h-12 w-full rounded-xl border-[1.5px] border-[var(--flow-ink)] bg-transparent px-3 outline-none focus-visible:ring-4 focus-visible:ring-[var(--flow-lime)]" />
      <label className="mt-3 block text-sm font-semibold" htmlFor="task-place">สถานที่</label>
      <div className="relative mt-1">
        <Search size={16} aria-hidden className="pointer-events-none absolute left-3 top-4 text-[var(--flow-muted)]" />
        <input
          id="task-place"
          name="place"
          role="combobox"
          aria-autocomplete="list"
          aria-haspopup="listbox"
          value={place.name}
          autoComplete="off"
          aria-describedby="task-place-help"
          aria-expanded={searchingPlace || placeHits.length > 0}
          aria-controls="task-place-results"
          placeholder="ค้นหาสถานที่ หรือพิมพ์ชื่อสถานที่"
          onChange={(event) => { const name = event.target.value; setPlace({ name }); setPlaceQuery(name); }}
          className="h-12 w-full rounded-xl border border-[var(--flow-line)] bg-transparent pl-10 pr-3"
        />
        {(searchingPlace || placeHits.length > 0) && placeQuery.trim().length >= 2 && (
          <div id="task-place-results" role="listbox" aria-label="ผลการค้นหาสถานที่" className="absolute inset-x-0 z-30 mt-1 max-h-52 overflow-y-auto rounded-xl border-[1.5px] border-[var(--flow-line)] bg-[var(--flow-paper)] p-1 shadow-[var(--flow-shadow)]">
            {searchingPlace && <p role="status" className="px-3 py-2 text-xs text-[var(--flow-muted)]">กำลังค้นหาสถานที่…</p>}
            {!searchingPlace && placeHits.map((hit) => (
              <button key={`${hit.lat}-${hit.lng}-${hit.name}`} type="button" role="option" aria-selected={place.lat === hit.lat && place.lng === hit.lng} onClick={() => { setPlace(hit); setPlaceQuery(""); setPlaceHits([]); }} className="flow-press flex min-h-11 w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs hover:bg-[var(--flow-surface)]">
                <MapPin size={14} aria-hidden className="shrink-0" /><span className="line-clamp-2">{hit.name}</span>
              </button>
            ))}
          </div>
        )}
      </div>
      <div id="task-place-help" className="mt-2 flex flex-wrap items-center gap-2 text-xs">
        <button type="button" onClick={() => setPickerOpen(true)} className="flow-press inline-flex min-h-11 items-center gap-1.5 rounded-xl border border-[var(--flow-line)] px-3 font-semibold"><MapPin size={14} aria-hidden />ปักหมุดบนแผนที่</button>
        {place.lat != null && place.lng != null ? <><span className="font-grotesk text-[var(--flow-muted)]">{place.lat.toFixed(4)}, {place.lng.toFixed(4)}</span><button type="button" className="min-h-11 px-2 font-semibold underline" onClick={() => { setPlace({ name: "" }); setPlaceQuery(""); }}>ลบสถานที่</button></> : <span className="text-[var(--flow-muted)]">เพิ่มพิกัดเพื่อใช้จัดเส้นทาง</span>}
      </div>
      <LocationPicker open={pickerOpen} onClose={() => setPickerOpen(false)} initial={place.lat != null && place.lng != null ? { lat: place.lat, lng: place.lng } : undefined} onPick={(picked) => { setPlace(picked); setPlaceQuery(""); setPlaceHits([]); setPickerOpen(false); }} />
      <div className="mt-3 grid grid-cols-2 gap-2"><label className="text-sm font-semibold">เริ่ม<input name="start" type="time" step="900" className="font-grotesk mt-1 h-12 w-full rounded-xl border border-[var(--flow-line)] bg-transparent px-2" /></label><label className="text-sm font-semibold">จบ<input name="end" type="time" step="900" className="font-grotesk mt-1 h-12 w-full rounded-xl border border-[var(--flow-line)] bg-transparent px-2" /></label></div>
      <label className="mt-3 block text-sm font-semibold">ระยะเวลา (ใช้เมื่อไม่ระบุเวลาจบ)<select name="duration" defaultValue="60" className="font-grotesk mt-1 h-12 w-full rounded-xl border border-[var(--flow-line)] bg-[var(--flow-paper)] px-2"><option value="15">15 นาที</option><option value="30">30 นาที</option><option value="45">45 นาที</option><option value="60">1 ชั่วโมง</option><option value="90">1.5 ชั่วโมง</option><option value="120">2 ชั่วโมง</option></select></label>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <label className="text-sm font-semibold">เส้นตายวันที่<input name="deadlineDate" type="date" min={date} className="font-grotesk mt-1 h-12 w-full rounded-xl border border-[var(--flow-line)] bg-transparent px-2" /></label>
        <label className="text-sm font-semibold">เวลา<input name="deadlineTime" type="time" className="font-grotesk mt-1 h-12 w-full rounded-xl border border-[var(--flow-line)] bg-transparent px-2" /></label>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <label className="text-sm font-semibold">ความสำคัญ<select name="priority" className="mt-1 h-12 w-full rounded-xl border border-[var(--flow-line)] bg-[var(--flow-paper)] px-2"><option value="urgent">ด่วน</option><option value="high">สำคัญ</option><option value="normal">ปกติ</option><option value="flex">ยืดหยุ่น</option></select></label>
        <label className="text-sm font-semibold">หมวดหมู่<select name="category" className="mt-1 h-12 w-full rounded-xl border border-[var(--flow-line)] bg-[var(--flow-paper)] px-2"><option value="">ไม่มีหมวดหมู่</option>{categories.map((category) => <option value={category.id} key={category.id}>{category.name}</option>)}</select></label>
      </div>
      <label className="mt-3 block text-sm font-semibold">ทำซ้ำ<select name="repeat" className="mt-1 h-12 w-full rounded-xl border border-[var(--flow-line)] bg-[var(--flow-paper)] px-2"><option value="none">ไม่ทำซ้ำ</option><option value="daily">ทุกวัน</option><option value="weekly">ทุกสัปดาห์</option><option value="monthly">ทุกเดือน</option><option value="yearly">ทุกปี</option></select></label>
      <fieldset className="mt-3"><legend className="text-sm font-semibold">แจ้งเตือนก่อนเริ่ม</legend><div className="mt-1 flex flex-wrap gap-2">{[[0,"ตรงเวลา"],[5,"5 นาที"],[10,"10 นาที"],[30,"30 นาที"],[60,"1 ชั่วโมง"]].map(([value,label]) => <label key={value} className="flex min-h-11 items-center gap-2 rounded-xl border border-[var(--flow-line)] px-3"><input name="reminder" type="checkbox" value={value} />{label}</label>)}</div></fieldset>
      <label className="mt-2 block text-sm">กำหนดเอง (นาที)<input name="reminder" type="number" min="0" max="10080" className="font-grotesk mt-1 h-11 w-full rounded-xl border bg-transparent px-3" /></label>
      <label className="mt-3 flex min-h-11 items-center gap-2"><input name="allDay" type="checkbox" />งานทั้งวัน</label>
      <label className="flex min-h-11 items-center gap-2"><input name="lockTime" type="checkbox" />ล็อกเวลา ไม่ให้ AI ขยับ</label>
      <label className="mt-2 block text-sm font-semibold">โน้ต<textarea name="note" rows={2} className="mt-1 w-full rounded-xl border border-[var(--flow-line)] bg-transparent p-3" /></label>
      <button className="flow-press flow-inverse mt-4 h-14 w-full rounded-2xl font-semibold" type="submit">บันทึกงาน</button>
    </form>
  );
}
