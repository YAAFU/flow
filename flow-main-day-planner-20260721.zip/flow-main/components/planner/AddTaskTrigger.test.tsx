import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { AddTaskTrigger } from "@/components/planner/TaskComposer";
import { TaskListView } from "@/components/planner/TaskListView";
import type { Task } from "@/lib/types";

const ADD_TRIGGER_SELECTOR = 'button[aria-label*="เพิ่มงาน"]';

const TASK: Task = {
  id: "task-1",
  title: "ประชุมทีม",
  place: "",
  priority: "normal",
};

let container: HTMLDivElement;
let root: Root;

function render(view: React.ReactNode) {
  act(() => root.render(view));
  return container;
}

function renderTaskList({
  tasks = [],
  isDayEmpty,
  onAdd = vi.fn(),
}: {
  tasks?: Task[];
  isDayEmpty?: boolean;
  onAdd?: () => void;
} = {}) {
  return render(
    <TaskListView
      tasks={tasks}
      categories={[]}
      onToggle={vi.fn()}
      onDelete={vi.fn()}
      onAdd={onAdd}
      isDayEmpty={isDayEmpty}
    />,
  );
}

beforeEach(() => {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
});

afterEach(() => {
  act(() => root.unmount());
  container.remove();
});

describe("unified add-task trigger", () => {
  it("renders exactly one trigger for a genuinely empty day", () => {
    const view = renderTaskList({ isDayEmpty: true });

    expect(view.querySelectorAll(ADD_TRIGGER_SELECTOR)).toHaveLength(1);
  });

  it("renders exactly one standalone trigger when the day already has tasks", () => {
    const view = render(
      <>
        <TaskListView
          tasks={[TASK]}
          categories={[]}
          onToggle={vi.fn()}
          onDelete={vi.fn()}
          onAdd={vi.fn()}
        />
        <AddTaskTrigger onClick={vi.fn()} />
      </>,
    );

    expect(view.querySelectorAll(ADD_TRIGGER_SELECTOR)).toHaveLength(1);
  });

  it("does not render an add trigger for an empty filtered result", () => {
    const view = renderTaskList({ isDayEmpty: false });

    expect(view.querySelectorAll(ADD_TRIGGER_SELECTOR)).toHaveLength(0);
  });

  it("uses the shared open callback from the empty-state trigger", () => {
    const onAdd = vi.fn();
    const view = renderTaskList({ isDayEmpty: true, onAdd });
    const trigger = view.querySelector<HTMLButtonElement>(ADD_TRIGGER_SELECTOR);

    expect(trigger).not.toBeNull();
    act(() => trigger?.click());
    expect(onAdd).toHaveBeenCalledTimes(1);
  });
});
