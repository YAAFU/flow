"use client";
/* eslint-disable react-hooks/immutability, react-hooks/set-state-in-effect, react-hooks/exhaustive-deps */
import { useEffect, useRef, useState } from "react";
import { Crosshair, MapPin, X } from "lucide-react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { BKK_CENTER } from "@/lib/places";

const STYLE = "https://basemaps.cartocdn.com/gl/positron-gl-style/style.json";
export type PickedLoc = { name: string; lat: number; lng: number };

function isValidPoint(value: unknown): value is { lat: number; lng: number } {
  if (typeof value !== "object" || value === null) return false;
  const point = value as { lat?: unknown; lng?: unknown };
  return typeof point.lat === "number" && Number.isFinite(point.lat) && point.lat >= -90 && point.lat <= 90
    && typeof point.lng === "number" && Number.isFinite(point.lng) && point.lng >= -180 && point.lng <= 180;
}

export function LocationPicker({ open, onClose, onPick, initial }:
  { open: boolean; onClose: () => void; onPick: (l: PickedLoc) => void; initial?: { lat: number; lng: number } }) {
  const ref = useRef<HTMLDivElement>(null);
  const dialogRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markerRef = useRef<maplibregl.Marker | null>(null);
  const reverseControllerRef = useRef<AbortController | null>(null);
  const reverseRequestRef = useRef(0);
  const openerRef = useRef<HTMLElement | null>(null);
  const onCloseRef = useRef(onClose);
  const [pin, setPin] = useState<{ lat: number; lng: number } | null>(null);
  const [name, setName] = useState<string>("");
  const [loadingName, setLoadingName] = useState(false);
  const [mapReady, setMapReady] = useState(false);
  const [mapError, setMapError] = useState("");
  const [mapAttempt, setMapAttempt] = useState(0);
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState("");

  useEffect(() => { onCloseRef.current = onClose; }, [onClose]);

  useEffect(() => {
    if (!open) return;
    openerRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onCloseRef.current();
        return;
      }
      if (event.key !== "Tab" || !dialogRef.current) return;
      const focusable = [...dialogRef.current.querySelectorAll<HTMLElement>("button:not([disabled]), [href], input:not([disabled]), [tabindex]:not([tabindex='-1'])")];
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === titleRef.current)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    };
    document.addEventListener("keydown", onKeyDown);
    const focusFrame = requestAnimationFrame(() => titleRef.current?.focus());
    return () => {
      cancelAnimationFrame(focusFrame);
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
      openerRef.current?.focus();
    };
  }, [open]);

  useEffect(() => {
    if (!open || !ref.current) return;
    reverseControllerRef.current?.abort();
    setPin(null);
    setName("");
    setLoadingName(false);
    setMapReady(false);
    setMapError("");
    setLocationError("");
    const start = isValidPoint(initial) ? initial : BKK_CENTER;
    let map: maplibregl.Map | null = null;
    let resizeObserver: ResizeObserver | undefined;
    let loadTimeout: ReturnType<typeof setTimeout> | undefined;
    try {
      map = new maplibregl.Map({ container: ref.current, style: STYLE, center: [start.lng, start.lat], zoom: 13, attributionControl: false });
      mapRef.current = map;
      const activeMap = map;
      loadTimeout = setTimeout(() => {
        if (!activeMap.isStyleLoaded()) setMapError("โหลดแผนที่ไม่สำเร็จ กรุณาลองใหม่");
      }, 12_000);
      activeMap.once("load", () => {
        if (loadTimeout) clearTimeout(loadTimeout);
        activeMap.resize();
        setMapReady(true);
      });
      activeMap.on("click", (event) => { void drop(event.lngLat.lat, event.lngLat.lng); });
      if (typeof ResizeObserver !== "undefined") {
        resizeObserver = new ResizeObserver(() => activeMap.resize());
        resizeObserver.observe(ref.current);
      }
      if (isValidPoint(initial)) void drop(initial.lat, initial.lng);
    } catch {
      setMapError("เปิดแผนที่ไม่ได้ในขณะนี้");
    }
    return () => {
      reverseControllerRef.current?.abort();
      if (loadTimeout) clearTimeout(loadTimeout);
      resizeObserver?.disconnect();
      try { map?.remove(); } catch {}
      mapRef.current = null;
      markerRef.current = null;
    };
  }, [open, initial?.lat, initial?.lng, mapAttempt]);

  async function drop(lat: number, lng: number) {
    if (!isValidPoint({ lat, lng })) return;
    setPin({ lat, lng });
    setName("");
    setLocationError("");
    const map = mapRef.current;
    if (map) {
      if (!markerRef.current) {
        const el = document.createElement("div");
        el.setAttribute("aria-label", "ตำแหน่งที่เลือก");
        el.style.cssText = "width:28px;height:28px;border:7px solid #111;border-radius:50%;background:#d6ff3f;box-shadow:0 1px 6px rgba(0,0,0,.35)";
        markerRef.current = new maplibregl.Marker({ element: el, anchor: "center" });
      }
      markerRef.current.setLngLat([lng, lat]).addTo(map);
    }
    reverseControllerRef.current?.abort();
    const controller = new AbortController();
    reverseControllerRef.current = controller;
    const requestId = ++reverseRequestRef.current;
    setLoadingName(true);
    try {
      const r = await fetch(`/api/geocode?lat=${lat}&lng=${lng}`, { signal: controller.signal });
      if (!r.ok) throw new Error("reverse geocode failed");
      const data = await r.json() as unknown;
      const nextName = typeof data === "object" && data !== null && typeof (data as { name?: unknown }).name === "string"
        ? (data as { name: string }).name.trim()
        : "";
      if (requestId === reverseRequestRef.current) setName(nextName || "หมุดที่ปัก");
    } catch {
      if (!controller.signal.aborted && requestId === reverseRequestRef.current) {
        setName("หมุดที่ปัก");
        setLocationError("ค้นชื่อสถานที่ไม่ได้ คุณยังใช้พิกัดนี้ได้");
      }
    } finally {
      if (requestId === reverseRequestRef.current) setLoadingName(false);
    }
  }

  function useCurrentLocation() {
    if (!("geolocation" in navigator)) {
      setLocationError("อุปกรณ์นี้ไม่รองรับตำแหน่งปัจจุบัน");
      return;
    }
    setLocating(true);
    setLocationError("");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocating(false);
        const next = { lat: position.coords.latitude, lng: position.coords.longitude };
        if (!isValidPoint(next) || !mapRef.current) return;
        mapRef.current.flyTo({ center: [next.lng, next.lat], zoom: 15, duration: 500 });
        void drop(next.lat, next.lng);
      },
      (error) => {
        setLocating(false);
        setLocationError(error.code === error.PERMISSION_DENIED ? "ไม่ได้รับอนุญาตให้ใช้ตำแหน่งปัจจุบัน" : "หาตำแหน่งปัจจุบันไม่สำเร็จ");
      },
      { enableHighAccuracy: true, timeout: 10_000, maximumAge: 60_000 },
    );
  }

  if (!open) return null;
  return (
    <>
      <div aria-hidden className="fixed inset-0 z-40 mx-auto max-w-[420px] bg-black/30" onClick={onClose} />
      <div ref={dialogRef} role="dialog" aria-modal="true" aria-labelledby="location-picker-title" aria-describedby="location-picker-help" className="flow-sheet fixed inset-x-0 bottom-0 z-50 mx-auto max-w-[420px] rounded-t-2xl border-t-[1.5px] border-[var(--flow-ink)] bg-[var(--flow-paper)] p-4 pb-[max(1.25rem,env(safe-area-inset-bottom))]">
        <div className="mx-auto mb-2 h-1 w-10 rounded-full bg-[var(--flow-line)]" />
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 ref={titleRef} tabIndex={-1} id="location-picker-title" className="text-base font-bold outline-none">ปักหมุดสถานที่</h3>
            <p id="location-picker-help" className="mt-0.5 text-xs text-[var(--flow-muted)]">แตะแผนที่หรือใช้ตำแหน่งปัจจุบัน</p>
          </div>
          <button type="button" aria-label="ปิดตัวเลือกสถานที่" onClick={onClose} className="flow-press grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-[var(--flow-line)]"><X size={18} /></button>
        </div>
        <button type="button" onClick={useCurrentLocation} disabled={locating || Boolean(mapError)} className="flow-press mt-3 flex min-h-11 w-full items-center justify-center gap-2 rounded-xl border-[1.5px] border-[var(--flow-ink)] px-3 text-sm font-semibold disabled:opacity-45"><Crosshair size={17} aria-hidden />{locating ? "กำลังหาตำแหน่ง…" : "ใช้ตำแหน่งปัจจุบัน"}</button>
        <div className="relative mt-2 h-[min(300px,42dvh)] min-h-[220px] w-full overflow-hidden rounded-xl border-[1.5px] border-[var(--flow-ink)]">
          <div ref={ref} aria-label="แผนที่สำหรับเลือกสถานที่" className="h-full w-full" />
          {!mapReady && !mapError && <div role="status" className="absolute inset-0 grid place-items-center bg-[var(--flow-surface)] text-sm text-[var(--flow-muted)]">กำลังเปิดแผนที่…</div>}
          {mapError && <div role="alert" className="absolute inset-0 flex flex-col items-center justify-center bg-[var(--flow-surface)] p-5 text-center"><MapPin size={22} aria-hidden /><p className="mt-2 text-sm font-semibold">{mapError}</p><button type="button" className="flow-press mt-3 min-h-11 rounded-xl border border-[var(--flow-ink)] px-4 text-sm font-semibold" onClick={() => setMapAttempt((attempt) => attempt + 1)}>ลองใหม่</button></div>}
        </div>
        <div aria-live="polite" className="mt-2 min-h-[20px] text-sm">
          {pin ? (
            <span><b>{loadingName ? "กำลังหาชื่อ…" : name}</b> <span className="font-grotesk text-xs text-[var(--flow-muted)]">{pin.lat.toFixed(4)}, {pin.lng.toFixed(4)}</span></span>
          ) : <span className="text-[var(--flow-muted)]">ยังไม่ได้ปักหมุด</span>}
        </div>
        {locationError && <p role="status" className="mt-1 text-xs text-[var(--flow-warning)]">{locationError}</p>}
        <div className="mt-3 flex gap-2">
          <button type="button" onClick={onClose} className="flow-press min-h-11 flex-1 rounded-xl border-[1.5px] border-[var(--flow-ink)] px-3 text-sm font-semibold">ยกเลิก</button>
          <button type="button" disabled={!pin || loadingName} onClick={() => pin && onPick({ name: name || "หมุดที่ปัก", lat: pin.lat, lng: pin.lng })}
            className="flow-press min-h-11 flex-[2] rounded-xl bg-[var(--flow-ink)] px-3 text-sm font-semibold text-[var(--flow-paper)] disabled:opacity-40">ใช้ตำแหน่งนี้</button>
        </div>
      </div>
    </>
  );
}
