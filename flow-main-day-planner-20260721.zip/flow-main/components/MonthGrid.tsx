"use client";
import { summarizeDayStatuses, type DayStatus as SemanticDayStatus } from "@/lib/day-status";

export type DayLoad = Record<number, number>; // day-of-month → heat 0..1
const DOW = ["อา","จ","อ","พ","พฤ","ศ","ส"];
const pad = (n: number) => String(n).padStart(2, "0");

export type DayStatus = SemanticDayStatus;
export type DayStatusInput = DayStatus | "done" | "miss";
type VisualDayStatus = Exclude<DayStatus, "empty">;

const STATUS_CELL: Record<VisualDayStatus, string> = {
  completed: "border-emerald-300 bg-emerald-50 text-emerald-950",
  pending: "border-sky-300 bg-sky-50 text-sky-950",
  failed: "border-red-300 bg-red-50 text-red-950",
};
// shape cue so colorblind users can still tell statuses apart (not color-only)
export const STATUS_MARK: Record<VisualDayStatus, string> = { completed: "✓", pending: "•", failed: "✕" };
const STATUS_LABEL: Record<VisualDayStatus, string> = { completed: "เสร็จแล้ว", pending: "มีงานรอ", failed: "ไม่สำเร็จ" };

function normalizeStatus(status?: DayStatusInput): DayStatus {
  if (status === "done") return "completed";
  if (status === "miss") return "failed";
  return status ?? "empty";
}

function getVisualStatus(status?: DayStatus): VisualDayStatus | undefined {
  return status && status !== "empty" ? status : undefined;
}

export function MonthGrid({ year, month, load, onPick, selected, labels, compact, today, pickMode, minDate, status, showStatusDetails }:
  { year: number; month: number; load: DayLoad; onPick: (day: number) => void; selected?: number; labels?: Record<number, string>; compact?: boolean; today?: number; pickMode?: boolean; minDate?: string; status?: Record<number, DayStatusInput>; showStatusDetails?: boolean }) {
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const normalizedStatus = Object.fromEntries(Object.entries(status ?? {}).map(([day, value]) => [day, normalizeStatus(value)])) as Record<number, DayStatus>;
  const summary = summarizeDayStatuses(Object.values(normalizedStatus));
  const renderStatusDetails = showStatusDetails ?? (!compact && status != null);

  // compact = the home calendar. Same elements whether browsing or picking-a-day;
  // pickMode only changes per-cell classes/height so the grid transitions in place.
  if (compact) {
    const EASE = "transition-all duration-300 ease-[cubic-bezier(.22,1,.36,1)]";
    return (
      <div>
        <div className={`grid grid-cols-7 text-center text-[9px] text-neutral-400 ${EASE} ${pickMode ? "gap-1" : "gap-0.5"}`}>
          {DOW.map((d, i) => <div key={i}>{d}</div>)}
        </div>
        <div className={`mt-0.5 grid grid-cols-7 ${EASE} ${pickMode ? "gap-1" : "gap-0.5"}`}>
          {cells.map((d, i) => {
            if (d === null) return <div key={i} />;
            const date = `${year}-${pad(month + 1)}-${pad(d)}`;
            const hasTasks = load[d] != null;
            const isSel = selected === d;
            const isToday = today === d;
            const disabled = !!pickMode && !!minDate && date < minDate;
            let cls: string;
            if (pickMode) {
              cls = disabled
                ? "text-neutral-300"
                : isSel
                  ? "bg-[var(--flow-inverse)] font-bold text-[var(--flow-inverse-text)]"
                  : hasTasks
                    ? "border border-neutral-200 text-neutral-400"
                    : "border-[1.5px] border-[var(--flow-ink)] font-bold text-[var(--flow-ink)]";
            } else {
              const st = getVisualStatus(normalizedStatus[d]);
              cls = st ? `${STATUS_CELL[st]} border font-semibold`
                : isToday ? "font-bold text-[var(--flow-ink)]" : "text-neutral-600";
            }
            const st = getVisualStatus(normalizedStatus[d]);
            const hasStatus = st != null;
            const showDot = hasTasks && !(pickMode && disabled) && !hasStatus && !isSel;
            return (
              <button key={i} disabled={disabled} onClick={() => !disabled && onPick(d)}
                aria-current={isToday ? "date" : undefined}
                aria-pressed={isSel}
                aria-label={`${d} ${DOW[new Date(year, month, d).getDay()]}${hasStatus ? ` · ${STATUS_LABEL[st]}` : ""}${hasTasks ? " · มีงาน" : ""}${isToday ? " · วันนี้" : ""}`}
                className={`font-grotesk relative flex flex-col items-center justify-center rounded-lg ${EASE} ${pickMode ? "h-11 text-sm" : "h-8 text-[11px]"} ${cls} ${isSel && !disabled ? "ring-2 ring-[var(--flow-ink)] ring-offset-1 ring-offset-[var(--flow-paper)]" : ""}`}>
                <span className={isToday && !disabled ? "underline decoration-[var(--flow-lime-dark)] decoration-2 underline-offset-2" : undefined}>{d}</span>
                {!pickMode && hasStatus && <span aria-hidden="true" className="absolute right-1 top-0.5 text-[8px] font-bold leading-none">{STATUS_MARK[st]}</span>}
                {showDot && <span className="absolute bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-[var(--flow-ink)]" style={{ opacity: 0.3 + (load[d] ?? 0) * 0.7 }} />}
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="grid grid-cols-7 gap-1 text-center text-[10px] text-neutral-400">
        {DOW.map((d, i) => <div key={i}>{d}</div>)}
      </div>
      <div className="mt-1 grid grid-cols-7 gap-1">
        {cells.map((d, i) => {
          if (d === null) return <div key={i} />;
          const st = getVisualStatus(normalizedStatus[d]);
          const hasStatus = st != null;
          const isSelected = selected === d;
          const isToday = today === d;
          return (
          <button key={i} onClick={() => onPick(d)} aria-current={isToday ? "date" : undefined} aria-pressed={isSelected}
            aria-label={`${d} ${DOW[new Date(year, month, d).getDay()]}${hasStatus ? ` · ${STATUS_LABEL[st]}` : ""}${load[d] != null ? " · มีงาน" : ""}${isToday ? " · วันนี้" : ""}`}
            className={`font-grotesk relative aspect-square rounded-lg border text-xs transition-[transform,background-color,border-color] duration-200 ${hasStatus ? STATUS_CELL[st] : "flow-hairline"} ${isSelected ? "ring-2 ring-[var(--flow-ink)] ring-offset-1 ring-offset-[var(--flow-paper)]" : ""}`}>
            <span className={`absolute left-1 top-1 ${isToday ? "underline decoration-[var(--flow-lime-dark)] decoration-2 underline-offset-2" : ""}`}>{d}</span>
            {hasStatus && <span aria-hidden="true" className="absolute right-1 top-1 text-[9px] font-bold leading-none">{STATUS_MARK[st]}</span>}
            {labels?.[d] && (
              <span className="absolute inset-x-0.5 bottom-3 truncate font-sans text-[7px] leading-none text-neutral-500">{labels[d]}</span>
            )}
            {load[d] != null && !hasStatus && (
              <span className="absolute bottom-1.5 left-1/2 h-1.5 -translate-x-1/2 rounded-full bg-[var(--flow-ink)]"
                style={{ width: `${6 + load[d]*16}px`, opacity: 0.25 + load[d]*0.75 }} />
            )}
          </button>
          );
        })}
      </div>
      {renderStatusDetails && (
        <div className="mt-4 border-t border-[var(--flow-line)] pt-3 text-xs">
          <div aria-label="คำอธิบายสถานะปฏิทิน" className="flex flex-wrap gap-x-3 gap-y-2 text-[var(--flow-muted)]" role="list">
            {(["completed", "pending", "failed"] as const).map((value) => (
              <span key={value} className="inline-flex items-center gap-1.5" role="listitem">
                <span aria-hidden="true" className={`grid h-5 w-5 place-items-center rounded-md border font-bold ${STATUS_CELL[value]}`}>{STATUS_MARK[value]}</span>
                {STATUS_LABEL[value]}
              </span>
            ))}
          </div>
          <p aria-live="polite" className="mt-2 text-[var(--flow-muted)]">
            เดือนนี้: เสร็จแล้ว <span className="font-grotesk font-semibold text-[var(--flow-ink)]">{summary.completed}</span> วัน · มีงานรอ <span className="font-grotesk font-semibold text-[var(--flow-ink)]">{summary.pending}</span> วัน · ไม่สำเร็จ <span className="font-grotesk font-semibold text-[var(--flow-ink)]">{summary.failed}</span> วัน
          </p>
        </div>
      )}
    </div>
  );
}
