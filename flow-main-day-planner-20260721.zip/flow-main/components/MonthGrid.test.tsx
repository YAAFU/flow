import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import { MonthGrid } from "@/components/MonthGrid";

let root: Root | undefined;
let container: HTMLDivElement | undefined;

function renderGrid(status: Record<number, "empty" | "completed" | "pending" | "failed" | "done" | "miss">) {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  act(() => {
    root?.render(
      <MonthGrid
        year={2026}
        month={6}
        load={{ 10: 0.5, 11: 0.5, 12: 0.5 }}
        onPick={vi.fn()}
        selected={11}
        today={10}
        status={status}
      />,
    );
  });
  return container;
}

afterEach(() => {
  act(() => root?.unmount());
  container?.remove();
  root = undefined;
  container = undefined;
});

describe("MonthGrid statuses", () => {
  it("keeps status cues visible for selected and current days", () => {
    const view = renderGrid({ 10: "completed", 11: "pending", 12: "failed" });
    const today = view.querySelector<HTMLButtonElement>('button[aria-current="date"]');
    const selected = view.querySelector<HTMLButtonElement>('button[aria-pressed="true"]');

    expect(today?.getAttribute("aria-label")).toContain("เสร็จแล้ว");
    expect(today?.textContent).toContain("✓");
    expect(selected?.getAttribute("aria-label")).toContain("มีงานรอ");
    expect(selected?.textContent).toContain("•");
    expect(selected?.className).toContain("ring-2");
    expect(view.querySelector('button[aria-label*="ไม่สำเร็จ"]')?.textContent).toContain("✕");
  });

  it("renders an accessible legend and live monthly summary", () => {
    const view = renderGrid({ 10: "completed", 11: "pending", 12: "failed" });
    const legend = view.querySelector('[role="list"][aria-label="คำอธิบายสถานะปฏิทิน"]');
    const summary = view.querySelector('[aria-live="polite"]');

    expect(legend?.textContent).toContain("เสร็จแล้ว");
    expect(legend?.textContent).toContain("มีงานรอ");
    expect(legend?.textContent).toContain("ไม่สำเร็จ");
    expect(summary?.textContent).toContain("เสร็จแล้ว 1 วัน");
    expect(summary?.textContent).toContain("มีงานรอ 1 วัน");
    expect(summary?.textContent).toContain("ไม่สำเร็จ 1 วัน");
  });

  it("normalizes legacy done and miss aliases", () => {
    const view = renderGrid({ 10: "done", 11: "miss" });
    expect(view.querySelector('button[aria-label*="เสร็จแล้ว"]')?.textContent).toContain("✓");
    expect(view.querySelector('button[aria-label*="ไม่สำเร็จ"]')?.textContent).toContain("✕");
  });
});
