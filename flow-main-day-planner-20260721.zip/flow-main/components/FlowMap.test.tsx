import React, { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { FlowMap } from "@/components/FlowMap";
import type { ScheduleItem } from "@/lib/types";

vi.mock("maplibre-gl", () => {
  class MockMap {
    isStyleLoaded() { return true; }
    once(event: string, callback: () => void) { if (event === "load") queueMicrotask(callback); }
    resize() {}
    flyTo() {}
    fitBounds() {}
    getSource() { return undefined; }
    addSource() {}
    addLayer() {}
    remove() {}
  }
  class MockMarker {
    setLngLat() { return this; }
    addTo() { return this; }
  }
  class MockBounds {
    extend() { return this; }
  }
  return { default: { Map: MockMap, Marker: MockMarker, LngLatBounds: MockBounds } };
});

const ITEM: ScheduleItem = {
  taskId: "task-1",
  title: "ประชุม",
  placeLabel: "สยาม",
  start: "09:00",
  end: "10:00",
  travelFromPrevMin: 0,
};

let container: HTMLDivElement;
let root: Root;

beforeEach(() => {
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("FlowMap", () => {
  it("shows an honest empty state when there are no scheduled items", async () => {
    await act(async () => root.render(<FlowMap items={[]} />));
    expect(container.textContent).toContain("ยังไม่มีงานที่จัดเวลา");
  });

  it("does not request or draw a road route for a single marker", async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal("fetch", fetchMock);

    await act(async () => {
      root.render(<FlowMap items={[ITEM]} coords={{ "task-1": { lat: 13.7456, lng: 100.5342 } }} />);
      await Promise.resolve();
    });

    expect(fetchMock).not.toHaveBeenCalled();
    expect(container.querySelector("[aria-label='แผนที่ลำดับสถานที่ของวัน']")).not.toBeNull();
  });

  it("explains that a location is required instead of rendering a fake map", async () => {
    const item = { ...ITEM, placeLabel: "" };
    await act(async () => root.render(<FlowMap items={[item]} />));
    expect(container.textContent).toContain("ยังไม่มีพิกัดสำหรับแสดงบนแผนที่");
    expect(container.querySelector("[aria-label='แผนที่ลำดับสถานที่ของวัน']")).toBeNull();
  });
});
