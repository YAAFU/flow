import { afterEach, describe, expect, it, vi } from "vitest";
import { NextRequest } from "next/server";
import { GET } from "@/app/api/geocode/route";

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("geocode API validation", () => {
  it("rejects incomplete or out-of-range reverse coordinates", async () => {
    const incomplete = await GET(new NextRequest("http://localhost/api/geocode?lat=13.7"));
    const outOfRange = await GET(new NextRequest("http://localhost/api/geocode?lat=91&lng=100"));
    const blank = await GET(new NextRequest("http://localhost/api/geocode?lat=&lng="));
    expect(incomplete.status).toBe(400);
    expect(outOfRange.status).toBe(400);
    expect(blank.status).toBe(400);
  });

  it("rejects an excessively long search query", async () => {
    const query = encodeURIComponent("ก".repeat(161));
    const response = await GET(new NextRequest(`http://localhost/api/geocode?q=${query}`));
    expect(response.status).toBe(400);
  });

  it("filters malformed and non-finite provider results", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => [
        { display_name: "เสีย", lat: "NaN", lon: "100.5" },
        { display_name: "นอกโลก", lat: "13.7", lon: "181" },
        { display_name: "สยาม, ปทุมวัน", name: "สยาม", lat: "13.7456", lon: "100.5342" },
      ],
    }));

    const response = await GET(new NextRequest(`http://localhost/api/geocode?q=${encodeURIComponent("สยาม")}`));
    const data = await response.json();
    expect(data).toEqual([{ name: "สยาม", lat: 13.7456, lng: 100.5342 }]);
  });
});
