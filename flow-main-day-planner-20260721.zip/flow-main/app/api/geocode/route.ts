import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

// Free geocoding via OpenStreetMap Nominatim (no API key). Server-side so we can
// set a proper User-Agent (per Nominatim usage policy) and bias to Bangkok.
const BKK_VIEWBOX = "100.30,13.95,100.95,13.50"; // lon,lat top-left → bottom-right
const GEOCODE_TIMEOUT_MS = 8_000;
const MAX_QUERY_LENGTH = 160;

type Hit = { name: string; lat: number; lng: number };
type NextFetchInit = RequestInit & { next?: { revalidate?: number } };

function isValidCoordinate(lat: number, lng: number): boolean {
  return Number.isFinite(lat) && lat >= -90 && lat <= 90
    && Number.isFinite(lng) && lng >= -180 && lng <= 180;
}

async function fetchWithTimeout(url: URL, init: NextFetchInit = {}): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), GEOCODE_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

export async function GET(req: NextRequest) {
  // reverse geocoding: ?lat=..&lng=.. → single place name for a dropped pin
  const latP = req.nextUrl.searchParams.get("lat");
  const lngP = req.nextUrl.searchParams.get("lng");
  if (latP !== null || lngP !== null) {
    const lat = Number(latP);
    const lng = Number(lngP);
    if (latP === null || lngP === null || !latP.trim() || !lngP.trim() || !isValidCoordinate(lat, lng)) {
      return NextResponse.json({ error: "invalid coordinates" }, { status: 400 });
    }
    const u = new URL("https://nominatim.openstreetmap.org/reverse");
    u.searchParams.set("lat", String(lat));
    u.searchParams.set("lon", String(lng));
    u.searchParams.set("format", "jsonv2");
    u.searchParams.set("accept-language", "th");
    try {
      const r = await fetchWithTimeout(u, { headers: { "User-Agent": "Flow-HacKaTech/1.0 (flow city planner demo)" } });
      if (!r.ok) return NextResponse.json({ name: "หมุดที่ปัก", lat, lng });
      const d = (await r.json()) as { name?: string; display_name?: string; address?: Record<string, string> };
      const a = d.address ?? {};
      const name = d.name || a.road || a.suburb || a.neighbourhood || a.quarter || d.display_name?.split(",")[0] || "หมุดที่ปัก";
      return NextResponse.json({ name, lat, lng });
    } catch {
      return NextResponse.json({ name: "หมุดที่ปัก", lat, lng });
    }
  }

  const q = req.nextUrl.searchParams.get("q")?.trim();
  if (!q || q.length < 2) return NextResponse.json([] as Hit[]);
  if (q.length > MAX_QUERY_LENGTH) return NextResponse.json({ error: "query too long" }, { status: 400 });

  // Nominatim is strict with long Thai names ("คณะวิศวกรรมศาสตร์ จุฬาลงกรณ์มหาวิทยาลัย"
  // finds nothing, "จุฬาลงกรณ์มหาวิทยาลัย" does) - so when the full query misses,
  // retry with leading/trailing words dropped until something hits
  const toks = q.split(/\s+/).filter(Boolean);
  const candidates = [q];
  for (let i = 1; i < toks.length; i++) candidates.push(toks.slice(i).join(" "));
  for (let i = toks.length - 1; i >= 1; i--) candidates.push(toks.slice(0, i).join(" "));
  for (const cand of [...new Set(candidates)].slice(0, 4)) {
    const hits = await searchNominatim(cand);
    if (hits.length) return NextResponse.json(hits);
  }
  return NextResponse.json([] as Hit[]);
}

async function searchNominatim(q: string): Promise<Hit[]> {
  const url = new URL("https://nominatim.openstreetmap.org/search");
  url.searchParams.set("q", q);
  url.searchParams.set("format", "jsonv2");
  url.searchParams.set("limit", "6");
  url.searchParams.set("countrycodes", "th");
  url.searchParams.set("viewbox", BKK_VIEWBOX);
  url.searchParams.set("bounded", "0"); // prefer the box but still allow outside
  url.searchParams.set("accept-language", "th");
  try {
    const r = await fetchWithTimeout(url, {
      headers: { "User-Agent": "Flow-HacKaTech/1.0 (flow city planner demo)" },
      // cache identical lookups a bit to be gentle on Nominatim
      next: { revalidate: 3600 },
    });
    if (!r.ok) return [];
    const data = await r.json() as unknown;
    if (!Array.isArray(data)) return [];
    return data.flatMap((value): Hit[] => {
      if (typeof value !== "object" || value === null) return [];
      const item = value as Record<string, unknown>;
      if ((typeof item.lat !== "string" && typeof item.lat !== "number")
        || (typeof item.lon !== "string" && typeof item.lon !== "number")
        || String(item.lat).trim() === "" || String(item.lon).trim() === "") return [];
      const lat = Number(item.lat);
      const lng = Number(item.lon);
      const displayName = typeof item.display_name === "string" ? item.display_name : "";
      const name = typeof item.name === "string" && item.name.trim() ? item.name.trim() : displayName.split(",")[0]?.trim();
      return name && isValidCoordinate(lat, lng) ? [{ name, lat, lng }] : [];
    });
  } catch {
    return [];
  }
}
