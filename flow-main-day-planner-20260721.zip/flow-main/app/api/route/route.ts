import { NextRequest, NextResponse } from "next/server";
import { durationTable, isValidPoint, roadRoute, type Pt } from "@/lib/osrm";

export const runtime = "nodejs";
const MAX_ROUTE_POINTS = 25;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const pts: Pt[] = Array.isArray(body?.coords) ? body.coords : [];
  const mode: string = body?.mode === "route" ? "route" : "table";
  if (pts.length < 2) return NextResponse.json({ error: "need >=2 coords" }, { status: 400 });
  if (pts.length > MAX_ROUTE_POINTS) return NextResponse.json({ error: `maximum ${MAX_ROUTE_POINTS} coords` }, { status: 400 });
  if (!pts.every(isValidPoint)) return NextResponse.json({ error: "invalid coords" }, { status: 400 });
  if (mode === "route") return NextResponse.json(await roadRoute(pts));
  return NextResponse.json(await durationTable(pts));
}
