import { describe, expect, it } from "vitest";
import { NextRequest } from "next/server";
import { POST } from "@/app/api/route/route";

function request(body: unknown) {
  return new NextRequest("http://localhost/api/route", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("route API validation", () => {
  it("requires at least two coordinates", async () => {
    const response = await POST(request({ mode: "route", coords: [{ lat: 13.7, lng: 100.5 }] }));
    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toEqual({ error: "need >=2 coords" });
  });

  it("rejects out-of-range coordinates instead of silently dropping them", async () => {
    const response = await POST(request({ mode: "route", coords: [
      { lat: 13.7, lng: 100.5 },
      { lat: 95, lng: 100.6 },
    ] }));
    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toEqual({ error: "invalid coords" });
  });

  it("caps route size before constructing an OSRM URL", async () => {
    const coords = Array.from({ length: 26 }, (_, index) => ({ lat: 13.7, lng: 100.4 + index / 1_000 }));
    const response = await POST(request({ mode: "route", coords }));
    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toEqual({ error: "maximum 25 coords" });
  });
});
