import { estimateTravelMin, type Place } from "./places";

// Real driving routes/times via OSRM public demo server (free, no API key).
// OSRM uses free-flow speeds, so we scale up to approximate Bangkok traffic.
const OSRM = "https://router.project-osrm.org";
const BKK_TRAFFIC = 1.5; // multiplier on free-flow driving time
const OSRM_TIMEOUT_MS = 8_000;

export type Pt = { lat: number; lng: number };
const asPlace = (p: Pt): Place => ({ name: "", lat: p.lat, lng: p.lng });
const coordStr = (pts: Pt[]) => pts.map((p) => `${p.lng},${p.lat}`).join(";");

export function isValidPoint(value: unknown): value is Pt {
  if (typeof value !== "object" || value === null) return false;
  const point = value as Partial<Pt>;
  return typeof point.lat === "number"
    && Number.isFinite(point.lat)
    && point.lat >= -90
    && point.lat <= 90
    && typeof point.lng === "number"
    && Number.isFinite(point.lng)
    && point.lng >= -180
    && point.lng <= 180;
}

async function osrmFetch(url: string): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), OSRM_TIMEOUT_MS);
  try {
    return await fetch(url, {
      headers: { "User-Agent": "Flow-HacKaTech/1.0" },
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeout);
  }
}

export type RouteResult = {
  geometry: [number, number][]; // [lng,lat][]
  legs: { durationMin: number; distanceKm: number }[];
  fallback: boolean;
};

// duration matrix (minutes) between every pair - one OSRM "table" call.
// Never throws - falls back to haversine estimates.
export async function durationTable(pts: Pt[]): Promise<{ durations: number[][]; fallback: boolean }> {
  try {
    if (pts.length < 2 || !pts.every(isValidPoint)) throw new Error("invalid points");
    const url = `${OSRM}/table/v1/driving/${coordStr(pts)}?annotations=duration`;
    const r = await osrmFetch(url);
    if (!r.ok) throw new Error(`osrm table ${r.status}`);
    const d = (await r.json()) as { durations: (number | null)[][] };
    if (!Array.isArray(d.durations) || d.durations.length !== pts.length) throw new Error("invalid duration table");
    let usedEstimate = false;
    return {
      durations: d.durations.map((row, fromIndex) => {
        if (!Array.isArray(row) || row.length !== pts.length) throw new Error("invalid duration row");
        return row.map((sec, toIndex) => {
          if (typeof sec === "number" && Number.isFinite(sec) && sec >= 0) return Math.round((sec / 60) * BKK_TRAFFIC);
          usedEstimate = true;
          return fromIndex === toIndex ? 0 : estimateTravelMin(asPlace(pts[fromIndex]), asPlace(pts[toIndex]));
        });
      }),
      fallback: usedEstimate,
    };
  } catch (e) {
    console.warn("[osrm] table unavailable, using estimate:", e instanceof Error ? e.message : e);
    return {
      durations: pts.map((a) => pts.map((b) => (a === b ? 0 : estimateTravelMin(asPlace(a), asPlace(b))))),
      fallback: true,
    };
  }
}

// real road geometry + per-leg duration/distance for an ordered route.
// Never throws - falls back to straight lines + haversine.
export async function roadRoute(pts: Pt[]): Promise<RouteResult> {
  try {
    if (pts.length < 2 || !pts.every(isValidPoint)) throw new Error("invalid points");
    const url = `${OSRM}/route/v1/driving/${coordStr(pts)}?overview=full&geometries=geojson&annotations=duration,distance`;
    const r = await osrmFetch(url);
    if (!r.ok) throw new Error(`osrm route ${r.status}`);
    const d = (await r.json()) as {
      routes: { geometry: { coordinates: [number, number][] }; legs: { duration: number; distance: number }[] }[];
    };
    const rt = d.routes?.[0];
    if (!rt || !Array.isArray(rt.geometry?.coordinates) || rt.geometry.coordinates.length < 2
      || !rt.geometry.coordinates.every(([lng, lat]) => isValidPoint({ lat, lng }))
      || !Array.isArray(rt.legs) || rt.legs.length !== pts.length - 1
      || !rt.legs.every((leg) => Number.isFinite(leg.duration) && leg.duration >= 0 && Number.isFinite(leg.distance) && leg.distance >= 0)) {
      throw new Error("invalid route response");
    }
    return {
      geometry: rt.geometry.coordinates,
      legs: rt.legs.map((l) => ({
        durationMin: Math.round((l.duration / 60) * BKK_TRAFFIC),
        distanceKm: +(l.distance / 1000).toFixed(1),
      })),
      fallback: false,
    };
  } catch (e) {
    console.warn("[osrm] route unavailable, using estimate:", e instanceof Error ? e.message : e);
    return {
      geometry: pts.map((p) => [p.lng, p.lat] as [number, number]),
      legs: pts.slice(1).map((p, i) => ({ durationMin: estimateTravelMin(asPlace(pts[i]), asPlace(p)), distanceKm: 0 })),
      fallback: true,
    };
  }
}
