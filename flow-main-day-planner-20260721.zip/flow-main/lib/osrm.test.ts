import { afterEach, describe, expect, it, vi } from "vitest";
import { durationTable, isValidPoint, roadRoute, type Pt } from "@/lib/osrm";

const POINTS: Pt[] = [
  { lat: 13.746, lng: 100.534 },
  { lat: 13.737, lng: 100.56 },
];

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe("OSRM helpers", () => {
  it("accepts only finite coordinates in geographic ranges", () => {
    expect(isValidPoint(POINTS[0])).toBe(true);
    expect(isValidPoint({ lat: Number.NaN, lng: 100 })).toBe(false);
    expect(isValidPoint({ lat: 91, lng: 100 })).toBe(false);
    expect(isValidPoint({ lat: 13, lng: 181 })).toBe(false);
  });

  it("uses a distance estimate instead of zero for an unreachable table cell", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ durations: [[0, null], [600, 0]] }),
    }));

    const result = await durationTable(POINTS);

    expect(result.fallback).toBe(true);
    expect(result.durations[0][1]).toBeGreaterThan(0);
    expect(result.durations[1][0]).toBe(15);
  });

  it("falls back deterministically when route geometry is invalid", async () => {
    vi.spyOn(console, "warn").mockImplementation(() => undefined);
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({
      ok: true,
      json: async () => ({ routes: [{ geometry: { coordinates: [[100.534, 13.746]] }, legs: [] }] }),
    }));

    const result = await roadRoute(POINTS);

    expect(result.fallback).toBe(true);
    expect(result.geometry).toEqual(POINTS.map((point) => [point.lng, point.lat]));
    expect(result.legs).toHaveLength(1);
    expect(result.legs[0].durationMin).toBeGreaterThan(0);
  });
});
